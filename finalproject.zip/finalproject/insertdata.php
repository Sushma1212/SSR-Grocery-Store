<?php
require "db.php";
$FirstName=mysqli_real_escape_string($con,$_GET['firstname']);
$LastName=mysqli_real_escape_string($con,$_GET['lastname']);
$username=mysqli_real_escape_string($con,$_GET['username']);
$password=mysqli_real_escape_string($con,$_GET['password']);
$email=mysqli_real_escape_string($con,$_GET['email']);
$salt="yughkjhbgvbhj";
$password1 =md5($password.$salt);
$check_user="SELECT * from users where username='$username'";
$user_result=mysqli_query($con,$check_user);
$check_email="SELECT * from users where email='$email'";
$email_result=mysqli_query($con,$check_email);
if(mysqli_num_rows($user_result)>0)
{
echo "Username already exists";
exit();
}
else if(mysqli_num_rows($email_result)>0)
{
echo "Email already exists";
exit();
}
else{
$query= "INSERT INTO users(username,first_name,last_name,email,password) VALUES('$username','$FirstName','$LastName','$email','$password1')";
$results=mysqli_query($con,$query);
echo "Registered successfully";
}
?>